<?php
require_once('../Controllers/Restorants.php');
$db = new Restorants();
$name = $_POST['Name'];
$des = $_POST['Des'];
//print_r($_FILES['image']);
if (isset($_FILES['image'])) {
    $asas = $_FILES['image']['name'];
    $tempname = $_FILES['image']['tmp_name'];
    $folder = "../drawable/" . $asas;
    if (move_uploaded_file($tempname, $folder)) {
        $msg = "Image uploaded successfully";
    } else {
        $msg = "Failed to upload image";
    }
}else {
    $asas = 'food-svgrepo-com.svg';
}
$res = $db->create(json_encode([
    'Name' => $name,
    'Description' => $des,
    'image' => $asas
]));
//echo $asas;
header('Location: ../restorans/restorans.php');