<?php
require_once('../Controllers/Orders.php');
$db = new Orders();
$id =$_POST['id'];
$data = $db->delete($id);
$_SESSION['message'] = 'Удаление прошло успешно!';
header('Location: ../orders/mainLK.php');