<?php
require_once ('../layouts/header.php');
require_once ('../layouts/menu.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ./index.php');
}?>
<main class="form-signin w-100 m-auto">
    <form action="../middleware/dishInsert.php" method="post" enctype="multipart/form-data" class="my-2">
        <h1 class="h3 mb-3 fw-normal">Добовление блюда</h1>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Name" name="Name">
            <label for="name">Название</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Des" name="Des">
            <label for="name">Описание</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="price" class="form-control" id="Price" name="Price">
            <label for="name">Цена</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="file" class="form-control" id="image" name="image">
            <label for="name">Изображение</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit">Создать блюдо</button>
    </form>
</main>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>
