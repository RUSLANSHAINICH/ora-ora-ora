<?php
require_once ("../Controllers/Orders.php");
session_start();
$db = new Orders();
$user = $_SESSION['users']->id;
$res = $_POST['res'];
$dish = $_POST['dish'];
$addres = $_SESSION['users']->Addres;
$stat = 2;

$res = $db->create(json_encode([
    'user'=>$user,
    'res'=>$res,
    'dish'=>$dish,
    'addres'=>$addres,
    'status'=>$stat,
]));
header('Location: ../orders/mainLK.php');