<?php
require_once('../Controllers/Users.php');

$db = new Users();
$ln = $_POST['Last_name'];
$Fn = $_POST['First_name'];
$fan = $_POST['Father_name'];
$email = $_POST['Email'];
$addres = $_POST['Address'];
$pas = $_POST['password'];
$role = $_POST['role'];

$response = $db->create(json_encode([
    'Last_name' => $ln,
    'First_name' => $Fn,
    'Father_name' => $fan,
    'Email' => $email,
    'Address'=>$addres,
    'Password' => hash('sha256', $pas),
    'idRole'=>$role,
]));
$_SESSION['message'] = 'регистрация прошла успешно!';
header('Location: ../users/users.php');