<?php
require_once ('../../controllers/Recipes.php');
$db = new Recipes();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];
$res = $db->updateRUS(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/admin/index.php?message='. json_decode($res)->message);
