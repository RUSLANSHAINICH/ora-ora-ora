<?php
require ('../../controllers/Recipes.php');
?>
<div class="container d-flex justify-content-between align-items-center ">
    <a class="knopka" href="index.php">Главная страница</a>
    <a class="knopka" href="create_rus.php">Опубликовать собственный рецепт</a>
</div>

<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <?php
        $user = new Recipes();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow" ; style="background-color: #ffffff;">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Блюдо: </span>
                        <span class="card-text"><?php echo $row['name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Ингридиенты: </span>
                        <span class="card-text"><?php echo $row['ingridients'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Рецепт: </span>
                        <span class="card-text"><?php echo $row['recipe'];?></span>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>