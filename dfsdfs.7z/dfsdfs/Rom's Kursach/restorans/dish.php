<?php
require_once('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once('../Controllers/Dishes.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ../index.php');
}?>
    <h2>Блюда</h2>
    <div class="admin_container">
        <a class="admin_button me-2" href="dishInsert.php">Добавить блюдо</a>
        <a class="admin_button me-2" href="dishUpdate.php">Изменить блюдо</a>
        <a class="admin_button me-2" href="dishDelete.php">Удалить блюдо</a>
    </div>
    <div class="table-wrapper">
        <table class="fl-table">
            <thead>
            <tr>
                <th>№</th>
                <th>Название</th>
                <th>Описание</th>
                <th>Цена</th>
                <th>Ссылка на изображение</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db = new Dishes();
            $data = $db->index();
            foreach ($data as $key => $row) {?>
                <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['Name']?></td>
                    <td><?php echo $row['Description']?></td>
                    <td><?php echo $row['Prise']?></td>
                    <td><img src="../drawable/<?php echo  $row['image']?>" width="500" alt="rover" /></td>
                </tr>
            <?php }?>
            <tbody>
        </table>
    </div>
<?php
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
}
unset($_SESSION['message']);
?>
<?php
require_once('../layouts/footer.php');
require_once('../layouts/end.php')
?>