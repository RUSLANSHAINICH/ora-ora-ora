<?php
require_once ('../layouts/header.php');
?>
<main class="form-signin w-100 m-auto">
    <form action="../middleware/authorization.php" method="post" class="my-2">
        <h1 class="h3 mb-3 fw-normal">Пожалуйста, войдите в систему</h1>

        <div class="form-floating mt-2 mb-2">
            <input type="email" class="form-control" id="Email" name="Email">
            <label for="floatingInput">Адрес электронной почты</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="password" class="form-control" id="password" name="password">
            <label for="floatingPassword">Пароль</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit">Войти</button>
        <p>Ещё не зарегистрированы?</p><a href="registration.php">Зарегистрируйтесь прямо сейчас!</a>
    </form>
</main>
<?php
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
}
unset($_SESSION['message']);
?>
<?php
require_once ('../layouts/end.php')
?>
