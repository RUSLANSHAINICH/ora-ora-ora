<?php
require ('../layout/header.php');
require ('../../controllers/Recipes_am.php');
?>
<div>
    <a class="knopka" href="american.php">Назад</a>
</div>
<div class="container mt-5">
    <form action="../../middleware/user/create_am.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-5">
            <label for="name">Название</label>
            <input id="name" name="name" type="text" class="form-control" placeholder="Введите название" required>
        </div>
        <div>
            <label for="ingridients">Ингридиенты</label>
            <textarea name="ingridients" id="ingridients" cols="130" rows="10" type="text" class="form-control" placeholder="Введите рецепт" maxlength="5000" required></textarea>
        </div>
<div>
            <label for="recipe">Рецепт</label>
        <textarea name="recipe" id="recipe" cols="130" rows="10" type="text" class="form-control" placeholder="Введите рецепт" maxlength="5000" required></textarea>
</div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div>
