<?php

class DB
{
	
    protected function connect($host, $db, $user, $password)
    {
        return new pdo ('mysql:host=' . $host . ';dbname=' . $db . ";charset=utf8", $user, $password);
    }
	
    protected function conn(){
        return $this->connect('localhost:3306','db','root','');
    }

    public function Request($connect, $query)
    {
        $MYSQL = $connect->query($query);
        $MYSQL->execute();
        return $MYSQL->fetchAll();
    }

    protected function transaction($connect,$query,$message)
    {
        try {
            $connect->beginTransaction();
            $connect->exec($query);
            $connect->commit();
            return json_encode([
                'message' => $message
            ]);
        } catch (PDOException $e) {
            $connect->rollBack();
            return json_encode([
                'message' => $e->getMessage()
            ]);
        }
    }
}