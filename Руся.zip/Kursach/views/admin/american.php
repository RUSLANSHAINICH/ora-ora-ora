<?php
require ('../layout/header.php');
require ('../../controllers/Recipes_am.php');
?>
<div class="container d-flex justify-content-between align-items-center ">
    <a class="knopka" href="index.php">Главная страница</a>
    <a class="knopka" href="update_am.php">Изменить рецепт</a>
        <a class="knopka" href="delete_am.php">Удалить рецепт</a>
</div>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/public/css/bootstrap.css">
    <title>Кулинарный справочник</title>
</head>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <?php
        $user = new Recipes_am();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow" ; style="background-color: #ffffff;">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Блюдо: </span>
                        <span class="card-text"><?php echo $row['name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Ингридиенты: </span>
                        <span class="card-text"><?php echo $row['ingridients'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Рецепт: </span>
                        <span class="card-text"><?php echo $row['recipe'];?></span>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>