<?php
require_once('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once ('../Controllers/Users.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ../index.php');
}?>
    <div class="table-wrapper">
        <table class="fl-table">
            <thead>
            <tr>
                <th></th>
                <th>Фамилия</th>
                <th>Имя</th>
                <th>Отчество</th>
                <th>Почта</th>
                <th>Пароль</th>
                <th>id Роли</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db = new Users();
            $data = $db->index();
            foreach ($data as $key => $row) {?>
                <form action="../middleware/usersDelete.php" method="post">
                    <tr>
                        <td><input type="text" class="form-control" id="id" name="id" value="<?php echo $row['id']?>" hidden required></td>
                        <td><?php echo $row['Last_name']?></td>
                        <td><?php echo $row['First_name']?></td>
                        <td><?php echo $row['Father_name']?></td>
                        <td><?php echo $row['Email']?></td>
                        <td><?php echo $row['Addres']?></td>
                        <td><?php echo $row['Password']?></td>
                        <td><?php echo $row['id_Role']?></td>
                        <td><button class="w-100 btn btn-lg btn-primary" type="submit">Удалить</button></td>
                    </tr>
                </form>
            <?php }?>
            <tbody>
        </table>
    </div>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>