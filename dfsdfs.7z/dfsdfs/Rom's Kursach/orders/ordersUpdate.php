<?php
require_once ('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once ('../Controllers/Orders.php')
?>
<div class="table-wrapper">
    <table class="fl-table">
        <thead>
        <tr>
            <th>№</th>
            <th>Ресторан</th>
            <th>ФИО</th>
            <th>Блюдо</th>
            <th>Адрес</th>
            <th>Цена</th>
            <th>Статус</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $db = new Orders();
        $data = $db->index();
        foreach ($data as $key => $row) {?>
            <form action='../middleware/ordersUpdate.php' method="post">
                <tr>
                    <td><input type="text" class="form-control" id="id" name="id" value="<?php echo $row['id']?>" hidden></td>
                    <td><?php echo $row['Restaurans']?></td>
                    <td><?php echo $row['Last_name'] .' '.  $row['First_name'] .' '. $row['Father_name']?></td>
                    <td><?php echo $row['Name']?></td>
                    <td><?php echo $row['Address']?></td>
                    <td><?php echo $row['Prise']?></td>
                    <td>
                        <select id="status" name="status">
                            <?php require_once ('../Controllers/Status.php');
                            $db = new Status();
                            $data = $db->index();
                            foreach ($data as $key=>$row){?>
                            <option value="<?php echo $row['Name']?>"><?php echo $row['Name']?></option>
                            <?php }?>
                        </select>
                    </td>
                    <td><button class="w-100 btn btn-lg btn-primary" type="submit">Изменить</button></td>
                </tr>
            </form>
        <?php }?>
        <tbody>
    </table>
</div>
<?php
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
}
unset($_SESSION['message']);
?>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>
