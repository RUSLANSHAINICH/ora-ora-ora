<?php

require ('db.php');

class Recipes_am extends DB
{
    public function get(){
        return $this->DBAll('SELECT * from american_kitchen');
    }
    public function createAmerican_kit($request){
        $req = json_decode($request);
        $name = $req->name;
        $ingridients = $req->ingridients;
        $recipe = $req->recipe;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO american_kitchen (name, ingridients, recipe) values ('{$name}','{$ingridients}','{$recipe}')");
            $connect->commit();
            return json_encode([
                'message'=>'Рецепт добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function delete($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from american_kitchen where id='.$req->id,
            'Рецепт удален');
    }
    public function updateAM($request){
        $req = json_decode($request);
        $id = $req->id;
        $name = $req->name;
        $ingridients = $req->ingridients;
        $recipe = $req->recipe;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("update american_kitchen set name='{$name}', ingridients='{$ingridients}', recipe='{$recipe}' where id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Рецепт изменен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}