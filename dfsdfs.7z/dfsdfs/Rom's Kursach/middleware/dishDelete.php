<?php
require_once('../Controllers/Dishes.php');
$db = new Dishes();
$id =$_POST['id'];
$data = $db->delete($id);
$_SESSION['message'] = 'Удаление прошло успешно!';
header('Location: ../restorans/dish.php');