<?php
require_once ('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once ('../Controllers/Users.php');
?>
<?php if(!$_SESSION['users']){
    header('Location: ../users/authorization.php');
}?>
<div class="container" style="height: 73vh;">
    <div class="card__wrapper">
        <div class="card m-2">
            <div class="card-body">
                <h5 class="card-title"><?php echo 'Фамилия: ' . $_SESSION['users']->Last_name.'
                 <br> Имя: '.$_SESSION['users']->First_name.' <br>
                 Отчество: '.$_SESSION['users']->Father_name; ?></h5>
                <div>
                    <span class="card-text"><?php echo 'Email: ' .$_SESSION['users']->Email.' <br> Адрес проживания: ' .$_SESSION['users']->Addres;?></span>
                </div>
                <div>
                <a href="../users/updateUsers.php" class="w-80 btn btn-lg btn-primary">Изменить</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
}
unset($_SESSION['message']);
?>
<?php
require_once ('../layouts/footer.php')
?>
