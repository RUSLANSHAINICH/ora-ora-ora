<?php
require_once ('../Controllers/Users.php');

$db = new Users();
$id = $_POST['id'];
$ln = $_POST['Last_name'];
$Fn = $_POST['First_name'];
$fan = $_POST['Father_name'];
$email = $_POST['Email'];
$addres = $_POST['Addres'];
$pas = $_POST['password'];

$response = $db->update(json_encode([
    'id'=>$id,
    'Last_name' => $ln,
    'First_name' => $Fn,
    'Father_name' => $fan,
    'Email' => $email,
    'Addres'=>$addres,
    'Password' => hash('sha256', $pas),
]));
header('Location: ../users/lk.php');