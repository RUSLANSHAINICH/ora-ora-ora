<header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <img class="bi me-2" width="45" height="40" src="../drawable/dilev.svg"/>
        <span class="fs-4" _msthash="1127126" _msttexthash="3261622">GastroExpress</span>
    </a>

    <?php if(isset($_SESSION['users']) and $_SESSION['users']->role_id == 1){?>
        <ul class="nav col-12 col-md-auto mb-2 justify-content-beetwen mb-md-0">
            <li><a href="../users/users.php" class="nav-link px-2">Пользователи</a></li>
            <li><a href="../restorans/dish.php" class="nav-link px-2">Блюда</a></li>
            <li><a href="../restorans/restorans.php" class="nav-link px-2">Рестораны</a></li>
            <li><a href="../restorans/restoransAndDish.php" class="nav-link px-2">Рестораны и блюда</a></li>
            <li><a href="../orders/main.php" class="nav-link px-2">Заказы</a></li>
        </ul>
    <?php }?>

    <?php if(isset($_SESSION['users']) and $_SESSION['users']->role_id == 3){?>
        <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
            <li><a href="../orders/main.php" class="nav-link px-2">Заказы</a></li>
        </ul>
    <?php }?>
    
    <?php if($_SERVER['REQUEST_URI'] == "/users/lk.php"){?>
    <!-- <a href="../users/updateUsers.php" class="items-menu me-2">Изменить</a> -->
    <a href="../middleware/logout.php" class="items-menu me-2">Выйти</a>
    <?php }else{?>
        <?php if(isset($_SESSION['users']) and $_SESSION['users']->role_id == 2){?>
            <a href="../orders/mainLK.php" class="items-menu me-2">Мои заказы</a>
    <?php }?>
    <?php if(isset($_SESSION['users'])){?>
        <a href="../users/lk.php" class="items-menu me-2">
            <img src="../drawable/person-circle.svg">
            <?php echo $_SESSION['users']->First_name ?>
        </a>
    <?php }else{?>
        <a href="../users/authorization.php" class="items-menu me-2">Войти</a>
        <a href="../users/registration.php" class="items-menu me-2">Регистрация</a>
    <?php }?>
    <?php }?>
</header>