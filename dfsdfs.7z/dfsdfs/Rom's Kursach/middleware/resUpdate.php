<?php
require_once ('../Controllers/Restorants.php');

$db = new Restorants();
$id = $_POST['id'];
$name = $_POST['Name'];
$des = $_POST['Description'];

$response = $db->update(json_encode([
    'id'=>$id,
    'name'=>$name,
    'Description' => $des,
]));

header('Location: ../restorans/restorans.php');
