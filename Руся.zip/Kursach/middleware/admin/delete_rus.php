<?php
require_once ('../../controllers/Recipes.php');
$db = new Recipes();
$id = $_POST['id'];

$res = $db->delete(json_encode([
    'id'=>$id
]));

header('Location: ../views/admin/index.php?message='. json_decode($res)->message);