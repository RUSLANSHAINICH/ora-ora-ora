<?php

require ('db.php');

class Recipes extends DB
{
    public function get(){
        return $this->DBAll('SELECT * from russian_kitchen');
    }
    public function createRussian_kit($request){
        $req = json_decode($request);
        $name = $req->name;
        $ingridients = $req->ingridients;
        $recipe = $req->recipe;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO russian_kitchen (name, ingridients, recipe) values ('{$name}','{$ingridients}','{$recipe}')");
            $connect->commit();
            return json_encode([
                'message'=>'Рецепт добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function delete($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from russian_kitchen where id='.$req->id,
            'Рецепт удален');
    }
    public function updateRUS($request){
        $req = json_decode($request);
        $id = $req->id;
        $name = $req->name;
        $ingridients = $req->ingridients;
        $recipe = $req->recipe;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("update russian_kitchen set name='{$name}', ingridients='{$ingridients}', recipe='{$recipe}' where id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Рецепт изменен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}