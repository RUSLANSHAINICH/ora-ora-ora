<?php
require_once ('../../controllers/Recipes_am.php');
$db = new Recipes_am();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];
$res = $db->updateAM(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/admin/index.php?message='. json_decode($res)->message);
