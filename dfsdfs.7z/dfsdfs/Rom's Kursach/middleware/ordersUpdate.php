<?php
require_once ('../Controllers/Orders.php');
session_start();
$db = new Orders();
$status = $_POST['status'];
$id = $_POST['id'];

$res = $db->update(json_encode([
    'status' => $status,
    'id'=>$id
]));
header('Location: ../orders/main.php');