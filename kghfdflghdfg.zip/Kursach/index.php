<?php
require_once('views/layout/header.php');
?>
<div class="border_width">
    <div class="container d-flex justify-content-between">
        <a class="knopka" href="views/auth/auth.php">Авторизация</a>
        <a class="knopka" href="views/auth/registration.php">Регистрация</a>
    </div>
</div>
<div style="display: grid; grid-template-columns: repeat(2,1fr); background-color:#edae8c;">
    <div class="card m-3 shadow card-body">
        <span class="card-text">Американская кухня</span>
       <div class="container"> <a class="perehod" href="views/kitchens/american.php" type="submit">Перейти</a>
       </div>
           <div>
            <img src="https://i.pinimg.com/236x/7a/5f/ad/7a5fad7c82d6bff8436c7a1aac11567d--vinyl-lettering-emblem.jpg?nii=t" class="card-img-top" alt="...">
        </div>
    </div>
    <div class="card m-3 shadow card-body">
        <span class="card-text">Азиатская кухня</span>
        <div class="container"><a class="perehod" href="views/kitchens/aziat.php" type="submit">Перейти</a></div>
        <div>
            <img src="https://w7.pngwing.com/pngs/332/217/png-transparent-east-asia-flags-of-asia-flag-of-malaysia-sicilian-flag-tattoos-flag-logo-flag-of-the-united-states-thumbnail.png" class="card-img-top" alt="...">
        </div>
    </div>

    <div class="card m-3 shadow card-body">
        <span class="card-text">Белорусская кухня</span>
        <div class="container">
        <a class="perehod" href="views/kitchens/belorussian.php" type="submit">Перейти</a>
        </div>
            <div>
            <img src="http://i.ytimg.com/vi/54WT14fSLuc/mqdefault.jpg" class="card-img-top" alt="...">
        </div>
    </div>

    <div class="card m-3  shadow card-body">
        <span class="card-text">Русская кухня</span>
        <div class="container"><a class="perehod" href="views/kitchens/russian.php" type="submit">Перейти</a>
        </div>
            <div>
            <img src="https://st03.kakprosto.ru/tumb/340/images/article/2014/3/28/1_533e5a25bc714533e5a25bc751.jpg" class="card-img-top" alt="...">
        </div>
    </div>
</div>
