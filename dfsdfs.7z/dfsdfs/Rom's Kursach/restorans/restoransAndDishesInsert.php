<?php
require_once ('../layouts/header.php');
require_once ('../layouts/menu.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ./index.php');
}?>
<main class="form-signin w-100 m-auto">
    <form action="../middleware/resdishinsert.php" method="post" enctype="multipart/form-data" class="my-2">
        <h1 class="h3 mb-3 fw-normal">Добовление</h1>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="res" name="res" list="res_list">
            <datalist id="res_list">
                <?php require_once ('../Controllers/Restorants.php');
                $db = new Restorants();
                $data = $db->index();
                foreach ($data as $key=>$row){?>
                    <option value="<?php echo $row['Name']?>"><?php echo $row['Name']?></option>
                <?php }?>
            </datalist>
            <label for="name">Ресторан</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="dish" name="dish" list="dish_list">
            <datalist id="dish_list">
                <?php require_once ('../Controllers/Dishes.php');
                $db = new Dishes();
                $data = $db->index();
                foreach ($data as $key=>$row){?>
                    <option value="<?php echo $row['Name']?>"><?php echo $row['Name']?></option>
                <?php }?>
            </datalist>
            <label for="name">Блюдо</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit">Создать</button>
    </form>
</main>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>
