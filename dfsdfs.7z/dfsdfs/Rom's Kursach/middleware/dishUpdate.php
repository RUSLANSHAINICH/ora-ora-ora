<?php
require_once ('../Controllers/Dishes.php');

$db = new Dishes();
$id = $_POST['id'];
$name = $_POST['Name'];
$des = $_POST['Description'];
$price = $_POST['Price'];

$response = $db->update(json_encode([
    'id'=>$id,
    'name'=>$name,
    'Description' => $des,
    'Price' => $price,
]));

header('Location: ../restorans/dish.php');
