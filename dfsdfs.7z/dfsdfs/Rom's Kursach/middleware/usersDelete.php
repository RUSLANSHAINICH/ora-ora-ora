<?php
require_once('../Controllers/Users.php');
$db = new Users();
$id =$_POST['id'];
$data = $db->delete($id);
$_SESSION['message'] = 'Удаление прошло успешно!';
header('Location: ../users/users.php');