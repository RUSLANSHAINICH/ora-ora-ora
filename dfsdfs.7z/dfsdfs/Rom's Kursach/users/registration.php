<?php
require_once ('../layouts/header.php');
?>

<main class="form-signin w-100 m-auto">
    <form action="../middleware/registration.php" method="post" class="my-2">
        <h1 class="h3 mb-3 fw-normal">Пожалуйста, зарегестрируйтесь в системе</h1>

        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Last_name" name="Last_name">
            <label for="name">Фамилия</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="First_name" name="First_name">
            <label for="name">Имя</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Father_name" name="Father_name">
            <label for="name">Отчество*(При наличии)</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" id="Email" name="Email">
            <label for="name">Email</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Address" name="Address">
            <label for="name">Адрес</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="password" class="form-control" id="password" name="password">
            <label for="name">Пароль</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="password" class="form-control" id="pass_con" name="pass_con">
            <label for="name">Повторите пароль</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit">Зарегистрироваться</button>
        <p>Уже зарегистрированы?</p><a href="authorization.php">Войдите в систему!</a>
    </form>
</main>
<?php
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
}
unset($_SESSION['message']);
?>
<?php
require_once ('../layouts/end.php')
?>
