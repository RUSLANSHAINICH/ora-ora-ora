<?php
session_start();
require_once('../controllers/Users.php');

$db = new Users();
$Email = $_POST['Email'];
$pas = $_POST['password'];

$response = $db->authorization(json_encode([
    'Email' => $Email,
    'password'=>hash('sha256',$pas)
]));
if(!$_SESSION['users']) {
    $_SESSION['message'] = 'Неправильный пароль или почта';
    header('Location: ../users/authorization.php');
}else{
    header('Location: ../../index.php');
}