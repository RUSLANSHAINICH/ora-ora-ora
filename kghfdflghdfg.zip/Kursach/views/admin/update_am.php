<?php
require_once('../layout/header.php');
require_once('../../controllers/Recipes_am.php');
$db = new Recipes_am();
?>
<div class="d-flex">
    <a class="knopka" href="american.php">Назад</a>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th>id</th>
        <th>Название</th>
        <th>Ингридиенты</th>
        <th>Рецепт</th>
        <th></th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->get();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/admin/update_am.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row["id"]; ?>" class="form-control" hidden required>
                </td>
                <td>
                    <input id="name" name="name" type="text" value="<?php echo $row["name"]; ?>" class="form-control" required>
                </td>
                <td>
                    <textarea id="ingridients" name="ingridients" type="text" required cols="55" rows="10"><?php echo $row["ingridients"]; ?></textarea>
                </td>
                <td>
                    <textarea id="recipe" name="recipe" type="text" required cols="55" rows="10"><?php echo $row["recipe"]; ?></textarea>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>