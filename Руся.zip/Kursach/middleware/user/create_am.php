<?php
require('../../controllers/Recipes_am.php');
$db = new Recipes_am();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];

$response = $db->createAmerican_kit(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/user/index.php?message='.json_decode($response)->message);