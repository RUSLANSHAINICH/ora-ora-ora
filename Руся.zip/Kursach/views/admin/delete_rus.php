<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Recipes.php');
?>
<div class="d-flex">
    <a class="knopka" href="russian.php">Назад</a>
</div>
<form name="search" method="post" action="../search.php">
    <input type="search" name="query" placeholder="Поиск">
    <button type="submit">Найти</button>
</form>
<title>Технический отдел по ремонту техники</title>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <?php
        $user = new Recipes();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow" ; style="background-color: #ffffff;">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Блюдо: </span>
                        <span class="card-text"><?php echo $row['name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Ингридиенты: </span>
                        <span class="card-text"><?php echo $row['ingridients'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Рецепт: </span>
                        <span class="card-text"><?php echo $row['recipe'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/admin/delete_rus.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
