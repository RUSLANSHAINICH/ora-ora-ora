<?php
require_once('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once('../Controllers/Users.php');
?>
<?php
$db = new Users();
?>
<main class="form-signin w-100 m-auto">
    <form action="../middleware/updateUsers.php" method="post" class="my-2">
        <div class="form-floating mt-2 mb-2">
            <input id="id" name="id" type="text" value="<?php ECHO $_SESSION['users']->id;?>" hidden required>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Last_name" name="Last_name" value="<?php ECHO $_SESSION['users']->Last_name?>">
            <label for="name">Фамилия</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="First_name" name="First_name" value="<?php ECHO $_SESSION['users']->First_name?>">
            <label for="name">Имя</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Father_name" name="Father_name" value="<?php ECHO $_SESSION['users']->Father_name?>">
            <label for="name">Отчество*(При наличии)</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="email" class="form-control" id="Email" name="Email" value="<?php ECHO $_SESSION['users']->Email?>">
            <label for="name">Адрес электронной почты</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Addres" name="Addres" value="<?php ECHO $_SESSION['users']->Addres?>">
            <label for="name">Адрес</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="password" class="form-control" id="password" name="password">
            <label for="name">Пароль</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary"  type="submit">изменить</button>
    </form>
</main>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>