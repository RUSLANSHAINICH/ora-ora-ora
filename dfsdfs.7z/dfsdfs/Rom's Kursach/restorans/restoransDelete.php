<?php
require_once('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once ('../Controllers/Restorants.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ../index.php');
}?>
    <div class="table-wrapper">
        <table class="fl-table">
            <thead>
            <tr>
                <th></th>
                <th>Название</th>
                <th>Описание</th>
                <th>Изображение</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db = new Restorants();
            $data = $db->index();
            foreach ($data as $key => $row) {?>
                <form action="../middleware/resDelete.php" method="post">
                    <tr>
                        <td><input type="text" class="form-control" id="id" name="id" value="<?php echo $row['id']?>" hidden required></td>
                        <td><?php echo $row['Name']?></td>
                        <td><?php echo $row['description']?></td>
                        <td><?php echo $row['image']?></td>
                        <td><button class="w-100 btn btn-lg btn-primary" type="submit">Удалить</button></td>
                    </tr>
                </form>
            <?php }?>
            <tbody>
        </table>
    </div>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>