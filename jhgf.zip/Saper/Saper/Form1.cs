namespace Saper
{
    public partial class Form1 : Form
    {
        int zagadka = 0;
        int ochko = 0;
        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnCount = 18;
            dataGridView1.RowCount = 10;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersVisible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
        }
        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            Random rndl = new Random();
            zagadka = rndl.Next(1, 100);
            label2.Text = zagadka.ToString();
            for (int i = 0; i < 18; i++)
            {
                for(int k = 0; k < 10; k++)
                {
                    Random rnd = new Random();
                    int chislo = rnd.Next(1, 100);
                    this.dataGridView1[i, k].Value = chislo.ToString();
                }
                Random rnd2 = new Random();
                int i1 = rnd2.Next(1, 11);
                int k1 = rnd2.Next(1, 10);
                this.dataGridView1[i1, k1].Value = zagadka.ToString();   
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string al = zagadka.ToString();
            string b =dataGridView1.CurrentCell.Value.ToString();
            dataGridView1.CurrentCell.Value = "0";
            if (al == b)
            {
                const string message = " ������ ������ �������?";
                const string zagolovok = "�� ���������.";
                var result=MessageBox.Show(message, zagolovok, MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(result == DialogResult.No)
                {
                    this.Close();
                }
                else
                {
                    button1.Enabled=true;
                }
            }
            else
            {
               int ochko1 = Convert.ToInt32(b);
                ochko = ochko + ochko1;
                label1.Text = ochko.ToString();
            }
            if (ochko>=1000)
            {

                MessageBox.Show("�� �������! ���!"); 
                this.Close();
            }
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Enabled = false;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //dataGridView1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}