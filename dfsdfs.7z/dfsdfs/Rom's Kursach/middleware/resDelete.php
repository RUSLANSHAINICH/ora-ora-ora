<?php
require_once('../Controllers/Restorants.php');
$db = new Restorants();
$id =$_POST['id'];
$data = $db->delete($id);
$_SESSION['message'] = 'Удаление прошло успешно!';
header('Location: ../restorans/restorans.php');