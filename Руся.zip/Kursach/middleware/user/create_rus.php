<?php
require('../../controllers/Recipes.php');
$db = new Recipes();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];

$response = $db->createRussian_kit(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/user/index.php?message='.json_decode($response)->message);