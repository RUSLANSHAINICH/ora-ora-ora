<?php
require('../../controllers/Recipes_az.php');
$db = new Recipes_az();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];

$response = $db->createAziat_kit(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/user/index.php?message='.json_decode($response)->message);