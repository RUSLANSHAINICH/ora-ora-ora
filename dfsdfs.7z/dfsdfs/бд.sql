-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 19 2022 г., 06:03
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Eat_Delivery`
--

-- --------------------------------------------------------

--
-- Структура таблицы `dishes`
--

CREATE TABLE `dishes` (
  `id` int NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Prise` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `dishes`
--

INSERT INTO `dishes` (`id`, `Name`, `Description`, `Prise`, `image`) VALUES
(1, 'Баскет', 'вкусно', '499', ''),
(10, 'цйууцйцу', 'йцуйцуйу', 'йцуйцуц', 'jorno.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `idUsers` int DEFAULT NULL,
  `idRest` int DEFAULT NULL,
  `idDishes` int DEFAULT NULL,
  `Address` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `idStatus` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `idUsers`, `idRest`, `idDishes`, `Address`, `idStatus`) VALUES
(9, 1, 1, 1, 'Ул Литвинова  17', 1),
(15, 8, 1, 1, 'ул Петрова 217', 3),
(16, 1, 1, 1, 'ул Петрова 217', 2),
(17, 15, 1, 1, 'ул Лермонтова 5а', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `restaurans_dishes`
--

CREATE TABLE `restaurans_dishes` (
  `idRestaurans` int NOT NULL,
  `idDishes` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `restaurans_dishes`
--

INSERT INTO `restaurans_dishes` (`idRestaurans`, `idDishes`) VALUES
(1, 1),
(15, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `restaurants`
--

CREATE TABLE `restaurants` (
  `id` int NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `restaurants`
--

INSERT INTO `restaurants` (`id`, `Name`, `description`, `image`) VALUES
(1, 'KFC', 'американская бургерная, фастфуд', 'https://www.thesun.co.uk/wp-content/uploads/2020/03/NINTCHDBPICT000345290476.jpg?strip=all&amp;quality=100&amp;w=1920&amp;h=1080&amp;crop=1'),
(15, 'йцуйцу', 'йцуйцуйу', 'jorno.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id` int NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `Name`) VALUES
(1, 'Администратор'),
(2, 'User'),
(3, 'Worker');

-- --------------------------------------------------------

--
-- Структура таблицы `status`
--

CREATE TABLE `status` (
  `id` int NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `status`
--

INSERT INTO `status` (`id`, `Name`) VALUES
(1, 'Уже прибыл'),
(2, 'Готовится'),
(3, 'В пути');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `Last_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `First_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Father_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Addres` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_Role` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `Last_name`, `First_name`, `Father_name`, `Addres`, `Email`, `Password`, `id_Role`) VALUES
(1, 'asdwdqf', 'asdqwqfqf', 'asfafqfqf', 'ул. Розылюксембург', 'qwefqwdqwd', 'e0aecec63d55af2d40f2ba6eeeff367f0185cd055797e06e2086c32682da54e4', 2),
(8, 'Петров', 'Петя', 'Петрович', 'ул Петрова 217', 'petya@petya', '2e37bf4bd9144b2abc03042f6e8789d084be078eda8e74c24f3f541b511d8c2d', 1),
(9, 'wewqeqweqweq', 'eqweqweqweqwe', 'qweqweqweqweqw', 'qweqeqweqrqrq', 'qweqweqw@qweqweqwe', 'c5f7520ad960ccd2b6287578270e469f76992f82527c199266deb2bf0845c910', 1),
(11, 'wqrqwtqtefgsdf', 'ffsdfdfsdfsdf', 'sfsdfsdfsdfsdf', 'esdggdfhghfdhh', 'sdfsf@sgsdgsgsd', '33894ba7ce5efc60ae6cbe3c000c0256b5fc1258af2724f561e9b676e7523ff0', 2),
(15, 'Леонтьев', 'Вячеслав', '', 'ул Лермонтова 5а', 'buster@yandex.ru', 'c9fe854ea69fc0a252340e152864b539b116c36cf1ac419652e1826c3071d5ed', 2),
(17, 'Всеволодов', 'Дмитрий', 'Витальевич', 'ул. Красных фонарей', 'daun@test', '44fd2ef63ab6b2e56439478bcb05947166771ae623c2e7c5d68851f12c47adae', 3);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_restaurants_id_fk` (`idRest`),
  ADD KEY `orders_status_id_fk` (`idStatus`),
  ADD KEY `orders_dishes_id_fk` (`idDishes`),
  ADD KEY `orders_users_id_fk` (`idUsers`);

--
-- Индексы таблицы `restaurans_dishes`
--
ALTER TABLE `restaurans_dishes`
  ADD KEY `idRestaurans` (`idRestaurans`),
  ADD KEY `idDishesl` (`idDishes`);

--
-- Индексы таблицы `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `users_roles_id_fk` (`id_Role`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `dishes`
--
ALTER TABLE `dishes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `status`
--
ALTER TABLE `status`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_dishes_id_fk` FOREIGN KEY (`idDishes`) REFERENCES `dishes` (`id`),
  ADD CONSTRAINT `orders_restaurants_id_fk` FOREIGN KEY (`idRest`) REFERENCES `restaurants` (`id`),
  ADD CONSTRAINT `orders_status_id_fk` FOREIGN KEY (`idStatus`) REFERENCES `status` (`id`),
  ADD CONSTRAINT `orders_users_id_fk` FOREIGN KEY (`idUsers`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `restaurans_dishes`
--
ALTER TABLE `restaurans_dishes`
  ADD CONSTRAINT `restaurans_dishes_ibfk_1` FOREIGN KEY (`idRestaurans`) REFERENCES `restaurants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `restaurans_dishes_ibfk_2` FOREIGN KEY (`idDishes`) REFERENCES `dishes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_roles_id_fk` FOREIGN KEY (`id_Role`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
