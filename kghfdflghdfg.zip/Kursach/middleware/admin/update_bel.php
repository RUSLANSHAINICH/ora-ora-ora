<?php
require_once ('../../controllers/Recipes_bel.php');
$db = new Recipes_bel();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];
$res = $db->updateBEL(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/admin/index.php?message='. json_decode($res)->message);
