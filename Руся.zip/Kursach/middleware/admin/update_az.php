<?php
require_once ('../../controllers/Recipes_az.php');
$db = new Recipes_az();
$id = $_POST['id'];
$name = $_POST['name'];
$ingridients = $_POST['ingridients'];
$recipe = $_POST['recipe'];
$res = $db->updateAZ(json_encode([
    'id'=>$id,
    'name'=>$name,
    'ingridients'=>$ingridients,
    'recipe'=>$recipe,
]));

header('Location: ../../views/users/index.php?message='.json_decode($res)->message);
