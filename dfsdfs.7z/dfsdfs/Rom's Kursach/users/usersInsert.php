<?php
require_once ('../layouts/header.php');
require_once ('../layouts/menu.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ../index.php');
}?>
<main class="form-signin w-100 m-auto">
    <form action="../middleware/CreateUsers.php" method="post" class="my-2">
        <h1 class="h3 mb-3 fw-normal">Добовление пользователя</h1>

        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Last_name" name="Last_name">
            <label for="name">Фамилия</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="First_name" name="First_name">
            <label for="name">Имя</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Father_name" name="Father_name">
            <label for="name">Отчество*(При наличии)</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="email" class="form-control" id="Email" name="Email">
            <label for="name">Адрес электронной почты</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="text" class="form-control" id="Address" name="Address">
            <label for="name">Адрес</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="password" class="form-control" id="password" name="password">
            <label for="name">Пароль</label>
        </div>
        <div class="form-floating mt-2 mb-2">
            <input type="number" class="form-control" id="role" name="role">
            <label for="name">id роли</label>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit">Создать пользователя</button>
    </form>
</main>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>
