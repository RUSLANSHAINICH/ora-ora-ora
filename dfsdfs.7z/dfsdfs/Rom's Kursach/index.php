<?php
require_once ('layouts/header.php');
require_once ('layouts/menu.php');
require_once ('Controllers/Restorants.php');
?>

<main class="container_main" style="height: 73vh;">
<h1 style="text-align: center;">Рестораны</h1>
<div class="container">
<?php
$db = new Restorants();
$data = $db->index();
foreach ($data as $key => $row) {
?>
<div class="card" >
    <div class="card-header">
        <a class="click_card" href="restorans/rers_menu.php?id=<?php echo $row['id'];?>">
        <img src="drawable/<?php echo  $row['image']?>" alt="rover" />
        </a>
    </div>
    <div class="card-body">
        <h4>
            <?php echo $row['Name'];?>
        </h4>
        <p>
            <?php echo $row['description'];?>
        </p>
    </div>
</div>
    <?php
    }
?>
</div>
</main>
<?php
require_once ('layouts/footer.php');
require_once ('layouts/end.php');
?>