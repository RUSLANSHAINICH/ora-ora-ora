<?php
require_once ('../Controllers/Orders.php');
session_start();
$db = new Orders();
$address = $_POST['address'];
$id = $_POST['id'];

$res = $db->updateLK(json_encode([
    'address' => $address,
    'id'=>$id
]));
header('Location: ../orders/mainLK.php');