<?php
require_once('../Controllers/RestouransAndDishes.php');
$db = new RestouransAndDishes();
$res = $_POST['res'];
$dish = $_POST['dish'];

$res = $db->create(json_encode([
    'res' => $res,
    'dish' => $dish,
]));
//var_dump($res);
header('Location: ../restorans/restoransAndDish.php');