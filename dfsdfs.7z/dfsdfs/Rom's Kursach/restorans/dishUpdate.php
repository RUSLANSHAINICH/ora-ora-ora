<?php
require_once('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once ('../Controllers/Dishes.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ./index.php');
}?>
    <div class="table-wrapper">
        <table class="fl-table">
            <thead>
            <tr>
                <th></th>
                <th>Название</th>
                <th>Описание</th>
                <th>Цена</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db = new Dishes();
            $data = $db->index();
            foreach ($data as $key => $row) {?>
                <form action="../middleware/dishUpdate.php" method="post">
                    <tr>
                        <td><input type="text" class="form-control" id="id" name="id" value="<?php echo $row['id']?>" hidden required></td>
                        <td><input type="text" class="form-control" id="Name" name="Name" value="<?php echo $row['Name']?>"></td>
                        <td><input type="text" class="form-control" id="Description" name="Description" value="<?php echo $row['Description']?>"></td>
                        <td><input type="text" class="form-control" id="Price" name="Price" value="<?php echo $row['Prise']?>"></td>
                        <td><button class="w-100 btn btn-lg btn-primary" type="submit">Изменить</button></td>
                    </tr>
                </form>
            <?php }?>
            <tbody>
        </table>
    </div>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>