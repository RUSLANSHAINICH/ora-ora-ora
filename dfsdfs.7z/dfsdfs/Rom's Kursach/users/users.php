<?php
require_once('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once('../Controllers/Users.php');
?>
<?php if (!$_SESSION['users']||$_SESSION['users']->role_id!=1){
    header('Location: ../index.php');
}?>
    <h2>Пользователи</h2>
    <div class="admin_container">
        <a class="admin_button me-2" href="usersInsert.php">Добавить пользователя</a>
        <a class="admin_button me-2" href="usersUpdate.php">Изменить пользователя</a>
        <a class="admin_button me-2" href="usersDelete.php">Удалить пользователя</a>
    </div>
    <div class="table-wrapper">
        <table class="fl-table">
            <thead>
            <tr>
                <th>№</th>
                <th>Фамилия</th>
                <th>Имя</th>
                <th>Отчество</th>
                <th>Адрес</th>
                <th>Почта</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db = new Users();
            $data = $db->index();
            foreach ($data as $key => $row) {?>
                <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['Last_name']?></td>
                    <td><?php echo $row['First_name']?></td>
                    <td><?php echo $row['Father_name']?></td>
                    <td><?php echo $row['Addres']?></td>
                    <td><?php echo $row['Email']?></td>
                </tr>
            <?php }?>
            <tbody>
        </table>
    </div>
<?php
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
}
unset($_SESSION['message']);
?>
<?php
require_once('../layouts/footer.php');
require_once('../layouts/end.php')
?>