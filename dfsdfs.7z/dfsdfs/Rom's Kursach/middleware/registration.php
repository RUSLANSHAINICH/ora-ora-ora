<?php
session_start();
require_once('../Controllers/Users.php');

$db = new Users();
$ln = $_POST['Last_name'];
$Fn = $_POST['First_name'];
$fan = $_POST['Father_name'];
$email = $_POST['Email'];
$addres = $_POST['Address'];
$pas = $_POST['password'];
$pass_con = $_POST['pass_con'];
$role = 2;

if ($fan == ''){
    $fan = null;
}

if ($pas === $pass_con) {
    $response = $db->create(json_encode([
        'Last_name' => $ln,
        'First_name' => $Fn,
        'Father_name' => $fan,
        'Email' => $email,
        'Address'=>$addres,
        'Password' => hash('sha256', $pas),
        'idRole'=>$role,
    ]));
    $_SESSION['message'] = 'регистрация прошла успешно!';
    header('Location: ../users/authorization.php');
}else{
    $_SESSION['message'] = 'Пароли не совпадают';
    header('Location: ../users/registration.php');
}