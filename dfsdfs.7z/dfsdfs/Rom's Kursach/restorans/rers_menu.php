<?php
require_once ('../layouts/header.php');
require_once ('../layouts/menu.php');
require_once ('../Controllers/RestouransAndDishes.php');
require_once ('../Controllers/Restorants.php');
$db = new RestouransAndDishes();
$data = $db->indexDish($_GET['id']);
?>
<div class="container_main">
<!--    --><?php
//    foreach ($data as $key => $row) {
//    ?>
<!--    <h1 class ="Title">--><?php //echo $row['']?><!--</h1>-->
<!--        --><?php
//    }
//    ?>
        <?php
        foreach ($data as $key => $row) {
            ?>
            <div class="card">
                <div class="card-header">
                    <img src="../drawable/<?php echo $row['dish_img']?>" alt="rover"/>
                </div>
                <div class="card-body">
                    <h4>
                        <?php echo $row['dishes'];?>
                    </h4>
                    <p>
                        <?php echo $row['Description'];?>
                    </p>
                    <h5>
                        <?php echo $row['Prise'];?>
                    </h5>
                </div>
                <form action="../middleware/createOrders.php" method="post">
                    <input type="text" class="form-control" value="<?php echo $row['res_id'];?>" hidden name="res">
                    <input type="text" class="form-control" value="<?php echo $row['dish_id'];?>" hidden name="dish">
                    <button class="btn btn-danger" type="submit">Заказать</button>
                </form>
            </div>
            <?php
        }
        ?>
    </ul>
</div>
<?php
require_once ('../layouts/footer.php');
require_once ('../layouts/end.php')
?>
